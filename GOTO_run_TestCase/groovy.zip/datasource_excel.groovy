//  JAVA CLASSES 
import java.io.File; 
import com.eviware.soapui.support.*;
import java.util.*; 
import jxl.*; 
import java.lang.*;

//  VARIABLE TO HOLD THE DATA SHEET NAME 
 sDataSheetName = "c:\\Users\\ext_kepperts\\Downloads\\soapUI\\vymaz z CBCB 2013_05_30.xls"


//  TO CREATE VARIABLES TO HOLD THE RESQUEST VALUES 
  def groovyUtils    =    new com.eviware.soapui.support.GroovyUtils( context );
  //def request        =    groovyUtils.getXmlHolder("deployCampaign_test#Request");


//  DECLARING VARIABLES FOR GLOBAL PROPERTIES
  def projectdir      =    context.expand('${#Global#PATH}');
  Workbook workbook      =    Workbook.getWorkbook(new File("c:\\Users\\ext_kepperts\\Downloads\\soapUI\\vymaz z CBCB 2013_05_30.xls"));
  Sheet sheet          =    workbook.getSheet("storno"); 
  rowcount            =  sheet.getRows();
  colcount            =  sheet.getColumns();

//  TO GET THE TEST CASE NAME
  def testCase = testRunner.getTestCase();
  Name = testCase.getName();
  
//  CHECK WHETHER THE TESTCASE NAMES MATCH
  for (tc_row in 1..rowcount)
      {
      Cell a1 = sheet.getCell(3,tc_row);
      String  s1 = a1.getContents();
  //    UISupport.showInfoMessage("${s1}")
      if ( Name == s1 ) 
        {
        current_row = tc_row;
        break;
        }
      }

//  TO CHECK FOR THE HEADER TAGS 
  for (tc_column in 2..colcount-1)
  {
      Cell a2= sheet.getCell(tc_column-1,0);
      String s2 = a2.getContents();
      //UISupport.showInfoMessage("${s2}")
      if (s2 != "" )
      {
        Cell a3= sheet.getCell(tc_column-1,current_row);
        String s3 = a3.getContents();
        //UISupport.showInfoMessage("${s3}")
            tag = s3;
            //SETS INPUT VALUES IN CORRESPONDING NODE
            request.setNodeValue("//icom:" + s2, "${tag}");
            request.updateProperty();        
      }  
      
  }