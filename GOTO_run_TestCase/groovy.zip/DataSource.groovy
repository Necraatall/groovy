/*</pre>
@Author : Stanislav Keppert
@Description : Data Source Looper responsible for looping a specific teststep.
@GroovyTestStepName : "Groovy Script - Data Loop"
@Version : "1.0" 
@Version : "1.1"
*/

import com.eviware.soapui.support.XmlHolder

def myTestCase = context.testCase
def counter,next,previous,size
	File tickerEnumFile =new File("c:\\Users\\ext_kepperts\\Downloads\\soapUI\\moje2.txt") //make sure input.txt file already exists and contains different set of values sepearted by new line (CR).
	List lines = tickerEnumFile.readLines()
size = lines.size.toInteger()
	propTestStep = myTestCase.getTestStepByName("Property - Looper") // get the Property TestStep
		propTestStep.setPropertyValue("Total", size.toString())
	counter = propTestStep.getPropertyValue("Count").toString()
	counter= counter.toInteger()
next = (counter > size-2? 0: counter+1)
	tempValue = lines[counter]
		propTestStep.setPropertyValue("Value", tempValue)
		propTestStep.setPropertyValue("Count", next.toString())
			next++
	log.info "Reading line : ${(counter+1)} / $lines.size"
		propTestStep.setPropertyValue("Next", next.toString())
	log.info "Value '$tempValue' -- updated in $propTestStep.name"
if (counter == size-1)
{
	propTestStep.setPropertyValue("StopLoop", "T")
	log.info "Setting the stoploop property now..."
}
else if (counter==0)
{
	def runner = new com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner(testRunner.testCase, null)
	propTestStep.setPropertyValue("StopLoop", "F")
}
else
{
	propTestStep.setPropertyValue("StopLoop", "F")
}