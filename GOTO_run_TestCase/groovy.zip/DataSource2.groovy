def size
File valueFile = new File("c:\\Users\\ext_kepperts\\Downloads\\soapUI\\data.txt") //make sure file already exists and contains different set of values separated by new line (CR).
List lines = valueFile.readLines()
size = lines.size.toInteger()
propTestStep = context.testCase.getTestStepByName("looper-props") // get the Property TestStep

for( counter in 0..size-1) // loops and runs a test case for each line in the file
{
tempValue = lines[counter]
propTestStep.setPropertyValue("Value", tempValue)
log.info tempValue
testRunner.runTestStepByName("AutoStortno_ESB");
}